function plothks(hks,orders)
wid = floor(log10(orders))+1;
wid = max(wid);
figure;
L = length(hks(:,1));
dat = length(hks(1,:));
col = rand(L,3);
for i = 1:L
    plot(1:dat,hks(i,:),1:dat,hks(i,:),'color',col(i,:),'marker','.','linewidth',1.2);hold on
end
if L <=20
    markes = cell(1,L);
    for i = 1:L
        markes(i) = {num2str(orders(i),['%0' num2str(wid) 'd'])};
    end
    legend(markes,'Fontsize',10);
end


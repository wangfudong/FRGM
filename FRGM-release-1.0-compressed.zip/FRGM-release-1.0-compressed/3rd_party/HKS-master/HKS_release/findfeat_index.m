function index_feat = findfeat_index(res,nei,t)
L = length(res(:,1));
index_feat = zeros(1,L);
res_t = res(:,t);
for i = 1:L
    neighbors = nei(i,:);
    pos = sum(neighbors>0);
    neighbors = neighbors(1:pos);
    res_tn = res_t(neighbors);
    if res_t(i) >= max(res_tn)
        index_feat(i) = 1;
    end
end

index_feat = find(index_feat>0);
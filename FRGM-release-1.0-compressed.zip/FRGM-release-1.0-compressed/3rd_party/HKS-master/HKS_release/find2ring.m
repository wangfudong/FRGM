function [index_vers] = find2ring(faces,ver)

[ind_ver1,~] = findneighbor(faces,ver);

L = length(ind_ver1);
ind_all = struct([]);
for i = 1:L
    ind_all(i).ind_ver = findneighbor(faces,ind_ver1(i));
    ind_all(i).ind_ver = setdiff(ind_all(i).ind_ver,ver);
end

% totle = 0;
% for i = 1:L
%     totle = totle + length(ind_all(i).ind_ver);
% end
index_vers = [];
for i = 1:L;
    index_vers = [ index_vers ; ind_all(i).ind_ver];
end
index_vers = unique(index_vers);
end
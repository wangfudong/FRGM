function M = measure_hks(hks1,hks2,type)
L1 = length(hks1(:,1));
L2 = length(hks2(:,1));
M = zeros(L1,L2);
L3 = length(hks1(1,:));

switch type
    case 'E'
        for i = 1:L3
            M = M + bsxfun(@minus,hks1(:,i),hks2(:,i)').^2;
        end
        M = sqrt(M);
        M = M/max(M(:));
    case 'K'
        M = hist_cost_2(hks1,hks2);
        M = M/max(M(:));
end










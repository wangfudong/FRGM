OFF2HKS.m:  Compute the heat kernel signatures given an mesh in off format. It
            uses MeshLP package (www.cs.princeton.edu/~jiansun/software/meshlp.html) to
            compute the eigenvalues and the eigenvectors of the Laplace operator. The time
            axis is sampled logarithmically.  example: OFF2HKS('trimstar.off', true)

HKS.m:      Compute the heat kernel signature for each point in the mesh given the
            eigenvalues and the eigenvectors of the Laplace operator. The time axis is
            sampled logarithmically. 

HKS_t.m:    Compute the heat kernel signature restricted to a given time scale
            given the eigenvalues and the eigenvectors of the Laplace operator. 



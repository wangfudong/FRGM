function [filename,vertice,face] = loadshapeoff(dataset,order)

switch dataset
    case 'face'
        dir = 'E:\computer_vision\code\date\3d\face';
        file_pt = ['face' num2str(order,'%02d')];
        filename = [dir '\' file_pt '.off'];
    case 'face205'
        dir = 'E:\computer_vision\code\date\3d\face205_ply\faceoffs';
        file_pt = ['face_mesh_' num2str(order,'%06d')];
        filename = [dir '\' file_pt '.off'];
    case 'kid1'
        dir = 'E:\computer_vision\code\date\3d\kids\off';
        file_pt = ['0001.isometry.' num2str(order)];
        filename = [dir '\' file_pt '.off'];
    case 'kid2'
        dir = 'E:\computer_vision\code\date\3d\kids\off';
        file_pt = ['0002.isometry.' num2str(order)];
        filename = [dir '\' file_pt '.off'];
    case 'topkid_low'
        dir = 'E:\computer_vision\code\date\3d\TOPKIDS\low resolution';
        file_pt = ['kid' num2str(order,'%02d')];
        filename = [dir '\' file_pt '.off'];
    case 'topkid_high'
        dir = 'E:\computer_vision\code\date\3d\TOPKIDS\high resolution';
        file_pt = ['kid' num2str(order,'%02d')];
        filename = [dir '\' file_pt '.off'];
end

 surface = loadoff4(filename);
 vertice = [surface.X,surface.Y,surface.Z];
 face = surface.TRIV + 1;
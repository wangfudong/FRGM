function [index_vers,index_faces] = findneighbor(faces,ver)

ind1 = find(faces(:,1) == ver);
ind2 = find(faces(:,2) == ver);
ind3 = find(faces(:,3) == ver);

index_faces = [ind1;ind2;ind3];

ind_v1 = faces(ind1,:);
ind_v2 = faces(ind2,:);
ind_v3 = faces(ind3,:);

ind_v1 = setdiff(ind_v1(:),ver);
ind_v2 = setdiff(ind_v2(:),ver);
ind_v3 = setdiff(ind_v3(:),ver);

index_vers = unique([ind_v1;ind_v2;ind_v3],'stable');




%% write off/1-ring neighbors,2-ring neighbors

%% write .off files of face ( 'E:\computer_vision\code\date\3d\face')

writefiles = 0;
if writefiles == 1
    dir = 'E:\computer_vision\code\date\3d\face';
    %for ii = 1:15
    order = ii;
    file_pt = ['face' num2str(order,'%02d')];
    file = [dir '\' file_pt '.mat'];
    surface = load(file);
    vertice = [surface.surface.X,surface.surface.Y,surface.surface.Z];
    face = surface.surface.TRIV;
    filename = ['E:\computer_vision\code\date\3d\face\' file_pt '.off'];
    writeoff(filename,vertice,face-1,[]);
    
    disp([dir '\' file_pt]);
    
    % save 1-ring neighbors,2-ring neighbors
    lengthver = length(vertice(:,1));
    nei1 = zeros(lengthver,100);
    nei2 = zeros(lengthver,100);
    num1 = zeros(1,lengthver);
    num2 = zeros(1,lengthver);
    Num1 = 0;
    Num2 = 0;
    for i = 1: lengthver
        tmp = findneighbor(face,i)';
        nei1(i,1:length(tmp)) = tmp;
        Num1 = max(Num1,length(tmp));
        tmp = find2ring(face,i)';
        nei2(i,1:length(tmp)) = tmp;
        Num2 = max(Num2,length(tmp));
    end
    nei1 = nei1(:,1:Num1);
    nei2 = nei2(:,1:Num2);
    matname1 = [file_pt '_nei1'];
    matname2 = [file_pt '_nei2'];
    
    save(['E:\computer_vision\code\date\3d\face\' matname1 '.mat'],'nei1');
    save(['E:\computer_vision\code\date\3d\face\' matname2 '.mat'],'nei2');
    
    % write HKS
    res = OFF2HKS(filename,true);
    hksname = [file_pt '_hks'];
    save(['E:\computer_vision\code\date\3d\face\' hksname '.mat'],'res');
    
    %end
end

%% compute and save face205 dataset
face205 = 1;
if face205 > 0
    fileindex = [336:30:1446]';%306;309;312
    dir = 'E:\computer_vision\code\date\3d\face205_ply\faceoffs';
    for ii = 1:length(fileindex(:,1))
        tic;
        order = fileindex(ii,:);
        file_pt = ['face_mesh_' num2str(order,'%06d')];
        file = [dir '\' file_pt '.off'];
        surface = loadoff4(file);
        vertice = [surface.X,surface.Y,surface.Z];
        face = surface.TRIV + 1;
        
        disp([dir '\' file_pt]);
          
        %repairface205_data(file);
        
        % load the repaired .off file
%         surface = loadoff4(file);
%         vertice = [surface.X,surface.Y,surface.Z];
%         face = surface.TRIV + 1;
         
        % save 1-ring neighbors,2-ring neighbors
%         lengthver = length(vertice(:,1));
%         nei1 = zeros(lengthver,100);
%         nei2 = zeros(lengthver,100);
%         num1 = zeros(1,lengthver);
%         num2 = zeros(1,lengthver);
%         Num1 = 0;
%         Num2 = 0;
%         for i = 1: lengthver
%             tmp = findneighbor(face,i)';
%             nei1(i,1:length(tmp)) = tmp;
%             Num1 = max(Num1,length(tmp));
%             tmp = find2ring(face,i)';
%             nei2(i,1:length(tmp)) = tmp;
%             Num2 = max(Num2,length(tmp));
%         end
%         nei1 = nei1(:,1:Num1);
%         nei2 = nei2(:,1:Num2);
%         matname1 = [file_pt '_nei1'];
%         matname2 = [file_pt '_nei2'];
%         
%         save(['E:\computer_vision\code\date\3d\face205_ply\faceoffs\' matname1 '.mat'],'nei1');
%         save(['E:\computer_vision\code\date\3d\face205_ply\faceoffs\' matname2 '.mat'],'nei2');
%         
%         % write HKS
%         res = OFF2HKS(file,true);
%         hksname = [file_pt '_hks'];
%         save(['E:\computer_vision\code\date\3d\face205_ply\faceoffs\' hksname '.mat'],'res');
        
        % compute geodesic distance
        
        
        load_index = load(['face_mesh_00' num2str(order,'%04d') '_landindex.mat']);
        load_index = load_index.land_index;
        [dmap,D] = geodis_map(vertice,face,load_index,'exact');
        save(['E:\computer_vision\code\date\3d\face205_ply\faceoffs\face_mesh_'...
            num2str(order,'%06d') '_dmap.mat'],'dmap');
        toc;
    end
    
end


%% compute and save topkid-low-resolution dataset
topkid_low = 0;
if topkid_low > 0
    
    dir = 'E:\computer_vision\code\date\3d\TOPKIDS\low resolution';
    for ii = 1:26
        order = ii-1;
        
            file_pt = ['kid' num2str(order,'%02d')];
            file = [dir '\' file_pt '.off'];
            surface = loadoff4(file);
            vertice = [surface.X,surface.Y,surface.Z];
            face = surface.TRIV + 1;
            
            disp([dir '\' file_pt]);
            
            % save 1-ring neighbors,2-ring neighbors
            lengthver = length(vertice(:,1));
            nei1 = zeros(lengthver,100);
            nei2 = zeros(lengthver,100);
            num1 = zeros(1,lengthver);
            num2 = zeros(1,lengthver);
            Num1 = 0;
            Num2 = 0;
            for i = 1: lengthver
                tmp = findneighbor(face,i)';
                nei1(i,1:length(tmp)) = tmp;
                Num1 = max(Num1,length(tmp));
                tmp = find2ring(face,i)';
                nei2(i,1:length(tmp)) = tmp;
                Num2 = max(Num2,length(tmp));
            end
            nei1 = nei1(:,1:Num1);
            nei2 = nei2(:,1:Num2);
            matname1 = [file_pt '_nei1'];
            matname2 = [file_pt '_nei2'];
            
            save(['E:\computer_vision\code\date\3d\TOPKIDS\low resolution\' matname1 '.mat'],'nei1');
            save(['E:\computer_vision\code\date\3d\TOPKIDS\low resolution\' matname2 '.mat'],'nei2');
            
            % write HKS
            res = OFF2HKS(file,true);
            hksname = [file_pt '_hks'];
            save(['E:\computer_vision\code\date\3d\TOPKIDS\low resolution\' hksname '.mat'],'res');
            
        
    end
    
end


%% compute and save topkid-high-resolution dataset
topkid_high = 1;
if topkid_high > 0
    
    dir = 'E:\computer_vision\code\date\3d\TOPKIDS\high resolution';
    for ii = 1:26
        order = ii-1;
        
            file_pt = ['kid' num2str(order,'%02d')];
            file = [dir '\' file_pt '.off'];
            surface = loadoff4(file);
            vertice = [surface.X,surface.Y,surface.Z];
            face = surface.TRIV + 1;
            
            disp([dir '\' file_pt]);
            
            % save 1-ring neighbors,2-ring neighbors
            lengthver = length(vertice(:,1));
            nei1 = zeros(lengthver,100);
            nei2 = zeros(lengthver,100);
            num1 = zeros(1,lengthver);
            num2 = zeros(1,lengthver);
            Num1 = 0;
            Num2 = 0;
            for i = 1: lengthver
                tmp = findneighbor(face,i)';
                nei1(i,1:length(tmp)) = tmp;
                Num1 = max(Num1,length(tmp));
                tmp = find2ring(face,i)';
                nei2(i,1:length(tmp)) = tmp;
                Num2 = max(Num2,length(tmp));
            end
            nei1 = nei1(:,1:Num1);
            nei2 = nei2(:,1:Num2);
            matname1 = [file_pt '_nei1'];
            matname2 = [file_pt '_nei2'];
            
            save(['E:\computer_vision\code\date\3d\TOPKIDS\high resolution\' matname1 '.mat'],'nei1');
            save(['E:\computer_vision\code\date\3d\TOPKIDS\high resolution\' matname2 '.mat'],'nei2');
            
            % write HKS
            res = OFF2HKS(file,true);
            hksname = [file_pt '_hks'];
            save(['E:\computer_vision\code\date\3d\TOPKIDS\high resolution\' hksname '.mat'],'res');
            
        
    end
    
end


%% compute and save kid dataset
kid = 1;
if kid > 0
    
    dir = 'E:\computer_vision\code\date\3d\kids\off';
    for ii = 1:15
        order = ii;
        for type = 1:2
            if type == 1
                file_pt = ['0001.isometry.' num2str(order)];
            else
                file_pt = ['0002.isometry.' num2str(order)];
            end
            file = [dir '\' file_pt '.off'];
            surface = loadoff4(file);
            vertice = [surface.X,surface.Y,surface.Z];
            face = surface.TRIV + 1;
            
            disp([dir '\' file_pt]);
            
            % save 1-ring neighbors,2-ring neighbors
            lengthver = length(vertice(:,1));
            nei1 = zeros(lengthver,100);
            nei2 = zeros(lengthver,100);
            num1 = zeros(1,lengthver);
            num2 = zeros(1,lengthver);
            Num1 = 0;
            Num2 = 0;
            for i = 1: lengthver
                tmp = findneighbor(face,i)';
                nei1(i,1:length(tmp)) = tmp;
                Num1 = max(Num1,length(tmp));
                tmp = find2ring(face,i)';
                nei2(i,1:length(tmp)) = tmp;
                Num2 = max(Num2,length(tmp));
            end
            nei1 = nei1(:,1:Num1);
            nei2 = nei2(:,1:Num2);
            matname1 = [file_pt '_nei1'];
            matname2 = [file_pt '_nei2'];
            
            save(['E:\computer_vision\code\date\3d\kids\off\' matname1 '.mat'],'nei1');
            save(['E:\computer_vision\code\date\3d\kids\off\' matname2 '.mat'],'nei2');
            
            % write HKS
            res = OFF2HKS(file,true);
            hksname = [file_pt '_hks'];
            save(['E:\computer_vision\code\date\3d\kids\off\' hksname '.mat'],'res');
            
        end
    end
    
end





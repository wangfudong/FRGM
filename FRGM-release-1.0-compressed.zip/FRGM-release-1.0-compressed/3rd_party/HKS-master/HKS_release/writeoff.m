function writeoff(filename,V,F,edge)
num_ver = length(V(:,1));
num_face = length(F(:,1));
if nargin < 3 || isempty(edge)
    num_ed = 0;
else
    num_ed = length(edge(:,1));
end
%delete(filename);
fid = fopen(filename,'w');
fprintf(fid,'OFF\n');
fprintf(fid,'%d %d %d\n',num_ver,num_face,num_ed);
for i=1:num_ver
    fprintf(fid,'%.6f %.6f %.6f\n',V(i,1),V(i,2),V(i,3));
end

for i=1:num_face
    fprintf(fid,'%d %d %d %d\n',3,F(i,1),F(i,2),F(i,3));
end

if  num_ed > 0
    for i=1:num_ed
        fprintf(fid,'%d %d %d\n',2,edge(i,1),edge(i,2));
    end
end

fclose(fid);

function repairface205_data(filename)

surface = loadoff4(filename);
vertice = [surface.X,surface.Y,surface.Z];
face = surface.TRIV+1;
num_ver = length(vertice(:,1));
face1 = unique(face(:));
index = setdiff(1:num_ver,face1);
index = sort(index);
if isempty(index) == 0
   vertice(index,:) = [];
   for i = 1: length(face(:,1))
       for j = 1:3
           face(i,j) = face(i,j) - sum(index <= face(i,j));
       end
   end
end

writeoff(filename,vertice,face-1,[]);




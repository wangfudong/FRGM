function [nei1,nei2,hks] = load_neiandhks(dataset,order)

switch dataset
    case 'face'
        dir = 'E:\computer_vision\code\date\3d\face';
        file_pt = ['face' num2str(order,'%02d')];
        fileres = [dir '\' file_pt '_hks' '.mat'];
        filenei1 = [dir '\' file_pt '_nei1' '.mat'];
        filenei2 = [dir '\' file_pt '_nei2' '.mat'];
    case 'face205'
        dir = 'E:\computer_vision\code\date\3d\face205_ply\faceoffs';
        file_pt = ['face_mesh_' num2str(order,'%06d')];
        fileres = [dir '\' file_pt '_hks' '.mat'];
        filenei1 = [dir '\' file_pt '_nei1' '.mat'];
        filenei2 = [dir '\' file_pt '_nei2' '.mat'];
    case 'kid1'
        dir = 'E:\computer_vision\code\date\3d\kids\off';
        file_pt = ['0001.isometry.' num2str(order)];
        fileres = [dir '\' file_pt '_hks' '.mat'];
        filenei1 = [dir '\' file_pt '_nei1' '.mat'];
        filenei2 = [dir '\' file_pt '_nei2' '.mat'];
    case 'kid2'
        dir = 'E:\computer_vision\code\date\3d\kids\off';
        file_pt = ['0002.isometry.' num2str(order)];
        fileres = [dir '\' file_pt '_hks' '.mat'];
        filenei1 = [dir '\' file_pt '_nei1' '.mat'];
        filenei2 = [dir '\' file_pt '_nei2' '.mat'];
    case 'topkid_low'
        dir = 'E:\computer_vision\code\date\3d\TOPKIDS\low resolution';
        file_pt = ['kid' num2str(order,'%02d')];
        fileres = [dir '\' file_pt '_hks' '.mat'];
        filenei1 = [dir '\' file_pt '_nei1' '.mat'];
        filenei2 = [dir '\' file_pt '_nei2' '.mat'];
    case 'topkid_high'
        dir = 'E:\computer_vision\code\date\3d\TOPKIDS\high resolution';
        file_pt = ['kid' num2str(order,'%02d')];
        fileres = [dir '\' file_pt '_hks' '.mat'];
        filenei1 = [dir '\' file_pt '_nei1' '.mat'];
        filenei2 = [dir '\' file_pt '_nei2' '.mat'];
end

hks = load(fileres);
hks = hks.res;
nei1 = load(filenei1);
nei1 = nei1.nei1;
nei2 = load(filenei2);
nei2 = nei2.nei2;
# HKS-heat-kernel-signature
the Matlab implement of heat kernel signature
the detail of HKS introduced in my blog "http://blog.csdn.net/sxf1061926959/article/details/53538105"

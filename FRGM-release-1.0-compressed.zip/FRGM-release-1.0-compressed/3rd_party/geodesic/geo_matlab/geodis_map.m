function [dis_map,dis_matrix] = geodis_map(V,F,ver_index,alg)
global geodesic_library;
geodesic_library = 'geodesic_release';

mesh = geodesic_new_mesh(V,F);         %initilize new mesh
algorithm = geodesic_new_algorithm(mesh, alg);      %initialize new geodesic algorithm

totle = length(V(:,1));
S = length(ver_index);
dis_map = zeros(S,totle);
dis_matrix = zeros(S,S);
for i = 1:S
        
        vertex_id = ver_index(i);                             %create a single source at vertex #1
        source_points = {geodesic_create_surface_point('vertex',vertex_id,V(vertex_id,:))};
        
        geodesic_propagate(algorithm, source_points);   %propagation stage of the algorithm (the most time-consuming)
        
        %distance1 = zeros(N,1);              %find distances to all vertices of the mesh (actual pathes are not computed)
        
        %find distances to all vertices of the mesh; in this example we have a single source, so source_id is always equal to 1
        [~, distance] = geodesic_distance_and_source(algorithm);
        dis_map(i,:) = distance;
        dis_matrix(i,:) = distance(ver_index);
       % geodesic_delete;%delete all meshes and algorithms
    
end
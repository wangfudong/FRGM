function [feat_index] = find_feat2(V,F,nei,option)
switch option.cues
    case 'cur'
        [GC,~] = curvatures(V,F);
        ind_feat = findfeat_index(abs(GC),nei,1);
        [feat_index,~] = removed_boundary(F,V,nei,ind_feat);
    case 'hks'
        ind_feat = findfeat_index(option.hks,nei,1);
        [feat_index,~] = removed_boundary(F,V,nei,ind_feat);
end

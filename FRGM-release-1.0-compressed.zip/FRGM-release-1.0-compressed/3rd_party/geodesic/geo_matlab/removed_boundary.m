function [feat_left,bound] = removed_boundary(tri,vertice,nei,feat_index)

tri3d = triangulation(tri,vertice);
bound = freeBoundary(tri3d);
bound = unique(bound);
for i = 1:length(feat_index)
    nei1 = nei(feat_index(i),:);
    L = sum(nei1>0);
    nei1 = nei1(1:L);
    same = intersect(bound,nei1);
    if isempty(same) == 0
        feat_index(i) = 0;
    end
end
feat_left = feat_index(feat_index>0);




















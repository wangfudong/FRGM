function [D,dmap,Path,dest] = geodis_path(V,F,ver_s,ver_t,alg)
global geodesic_library;
geodesic_library = 'geodesic_release';
mesh = geodesic_new_mesh(V,F);         %initilize new mesh
algorithm = geodesic_new_algorithm(mesh, alg);      %initialize new geodesic algorithm

S = length(ver_s);
T = length(ver_t);
Path = struct([]);
dest = struct([]);
D = zeros(S,T);
totle = length(V(:,1));
dmap = zeros(S,totle);

for i = 1:S
    for j = 1:T
        %         global geodesic_library;
        %         geodesic_library = 'geodesic_release';
        if i~=j
            vertex_id = ver_s(i);                             %create a single source at vertex #1
            source_points = {geodesic_create_surface_point('vertex',vertex_id,V(vertex_id,:))};
            
            geodesic_propagate(algorithm, source_points);   %propagation stage of the algorithm (the most time-consuming)
            
            vertex_id = ver_t(j);                              %create a single destination at vertex #N
            destination = geodesic_create_surface_point('vertex',vertex_id,V(vertex_id,:));
            Path(i,j).path = geodesic_trace_back(algorithm, destination);     %find a shortest path from source to destination
            dest(i,j).destination = destination;
            %distance1 = zeros(N,1);              %find distances to all vertices of the mesh (actual pathes are not computed)
            
            %find distances to all vertices of the mesh; in this example we have a single source, so source_id is always equal to 1
            [~, distance] = geodesic_distance_and_source(algorithm);
            D(i,j) = distance(ver_t(j));
            % geodesic_delete;%delete all meshes and algorithms
            dmap(i,:) = distance;
        end
        
    end
end
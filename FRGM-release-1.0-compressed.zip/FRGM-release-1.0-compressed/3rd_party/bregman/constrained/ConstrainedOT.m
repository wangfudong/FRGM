function [gamma] = ConstrainedOT(x,y,m,n,gamma0,hbar)
%CONSTRAINEDOT This function solves the capacity constrained transport by using the Dykstra Algorithm
%see section 8.2 of  Benamou,Carlier,Cuturi,Nenna and Peyré,  ¨Iterative Bregman Projections for Regularized Transportation Problems¨ 
%INPUT
%   x,y grid associated to the first and the second marginal
%   m,n are \mu and \nu
%   gamma0 must be the matrix \gamma_{ij}=exp^{-c_{ij}/lambda} where c_{ij} is the cost matrix for the OT problem
%   hbar is the matrix associated to the capacity constraint on \gamma 
%   lambda is the entropic regularization
%OUTPUT
% gamma is the optimal transport plan

% (c) Luca Nenna



N=length(x);
wx=x(2)-x(1);
wy=y(2)-y(1);

err=1.0;



%matrices for Dykstra
q1=ones(N,N);
q2=q1;
q3=q1;
gamma1=gamma0;
gamma2=gamma0;
gamma3=gamma0;
gamma=gamma0;

oo=ones(1,N);
count=1;

C=3;
%% loop
while (err)>3e-3 && count <= 100

if mod(count,C)==1
    str = sprintf('Proj on C1');
    disp(str);
    tmp=gamma.*q1;

    gammaN=min(tmp,hbar);
    q1=(tmp./gammaN);
    gamma1=gammaN;
    
      max_t = max(tmp(:));
        min_t = min(tmp(:));
        max_q1 = max(max(q1));
        min_q1 = min(min(q1));
        max_ga = max(gammaN(:));
        min_ga = min(gammaN(:));
        disp(['max_t: ' num2str(max_t) '  min_t: ' num2str(min_t)]);
        disp(['max_q1: ' num2str(max_q1) '  min_q1: ' num2str(min_q1)]);
        disp(['max_ga1: ' num2str(max_ga) '  min_ga1: ' num2str(min_ga)]);
    
elseif mod(count,C)==2
    str = sprintf('Proj on C2');
    disp(str);
    tmp=gamma.*q2;
    gammaN=tmp.*((m./(sum(tmp,2)))*oo);
    q2=(tmp./gammaN);
    gamma2=gammaN;
    
      max_t = max(tmp(:));
        min_t = min(tmp(:));
        max_q2 = max(max(q2));
        min_q2 = min(min(q2));
        max_ga = max(gammaN(:));
        min_ga = min(gammaN(:));
        disp(['max_t: ' num2str(max_t) '  min_t: ' num2str(min_t)]);
        disp(['max_q2: ' num2str(max_q2) '  min_q2: ' num2str(min_q2)]);
        disp(['max_ga2: ' num2str(max_ga) '  min_ga2: ' num2str(min_ga)]);

else
    str = sprintf('Proj on C3');
    disp(str);
    tmp=gamma.*q3;
    gammaN=tmp.*(oo'*(n./(sum(tmp,1))));    
    q3=(tmp./gammaN);
    gamma3=gammaN;
    
     max_t = max(tmp(:));
        min_t = min(tmp(:));
        max_q3 = max(max(q3));
        min_q3 = min(min(q3));
        max_ga = max(gammaN(:));
        min_ga = min(gammaN(:));
        disp(['max_t: ' num2str(max_t) '  min_t: ' num2str(min_t)]);
        disp(['max_q3: ' num2str(max_q3) '  min_q1: ' num2str(min_q3)]);
        disp(['max_ga3: ' num2str(max_ga) '  min_ga3: ' num2str(min_ga)]);
    
    
end
    

if count >3
err=(sum(sum(abs(gammaN-gamma1)))+sum(sum(abs(gammaN-gamma2)))+sum(sum(abs(gammaN-gamma3))))*wx*wy;
end

str = sprintf('Error at step (%d): %d', count, err);
disp(str);
gamma=gammaN;
count=count+1;
end


%plot gamma
figure,pcolor(x,y,gamma)
shading flat;
colormap gray
colormap(flipud(colormap))
colorbar;


end


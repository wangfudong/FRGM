% (c) Luca Nenna
%grid
N=200;
xa=0;
xb=1;
ya=0;
yb=1;
x=linspace(xa,xb,N);
y=linspace(ya,yb,N);

%marginals
mu=@(x) (x>=xa).*(x<=xb);
nu=@(x) (x>=ya).*(x<=yb);
oo=ones(1,N);
lambda=1.e-3;
%% cost matrix
h=@(x,y) exp(-0.5*(abs(x-y).^2)/lambda);
gamma0=h(oo'*x,y'*oo);
% h=@(x,y) abs(x-y).^2/lambda;
% gamma0 = (h(oo'*x,y'*oo)).^(1/2);
% gamma0 = gamma0/median(gamma0(:));

figure,imagesc(gamma0);
%capacity constrained
hbar=1.5/N*ones(N,N);
%if the marginals have not the same total mass they must be normalized
m=mu(x)';
n=nu(y);
[gamma] = ConstrainedOT(x,y,m,n,gamma0,hbar);
figure,imagesc(gamma);
figure,mesh(gamma)
function [Map,iter,err_hold,con_out] = Constrained_OT(p,q,M,constraint,lambda,stop_tol,max_iter)
% input
% p: histogram m*1 vector, marginal constraint
% q: histogram n*1 vector, marginal constraint
% M: M_i,j=d(p_i,q_j), ground-distance matrix
% lambda: positive,parameter for entropy regularization,
% stop_tol: tolerance for the relative error to stop iteration
% max_iter: maxima of the iteration

%output
% Map: transportation map, m*n matrix
% iter: iteration times
% err_hold: errors in iteration
%% checking the input
if nargin < 4
    error('no enough inputs');
end

if nargin < 5 || isempty(lambda)
    lambda = 1/100;
end

if nargin < 6 || isempty(stop_tol)
    stop_tol = 1.0e-5;
end


if nargin < 7 || isempty(max_iter)
    max_iter = 5000;
end

%%
%M = M/median(M(:));

gamma0 = exp(-1/lambda * M);
%gamma0 = M;
I_p = (p>0);
%I_p_index = find(p > 0);
I_q = (q>0);
%I_q_index = find(q > 0);
p = p(I_p);
q = q(I_q);
gamma0 = gamma0(I_p,I_q);
m = length(p);
%dm = 1/m;
I_m = ones(m,1);
n = length(q);
%dn = 1/n;
I_n = ones(n,1);

%matrices for Dykstra
q1 = ones(m,n);
q2 = q1;
q3 = q1;

con_out.c1 = zeros(max_iter,6);
con_out.c2 = zeros(max_iter,6);
con_out.c3 = zeros(max_iter,6);


gamma1 = gamma0;
gamma2 = gamma0;
gamma3 = gamma0;
gammaN = gamma0;

err_hold = zeros(max_iter,1);
err = 1;
cnt = 1;
C = 3;

%% loop

while (err) > stop_tol && cnt <= max_iter
    
    if mod(cnt,C) == 1
        disp('Pro on C1');
        
        tmp = gammaN.*q1;
        tmp(isnan(tmp)) = 0;
        gammaN = min(tmp,constraint);
        q1 = (tmp./gammaN);
        gamma1 = gammaN;
        
        con_out.c1(cnt,1) = max(tmp(:));
        con_out.c1(cnt,2) = min(tmp(:));
        con_out.c1(cnt,3) = max(q1(:));
        con_out.c1(cnt,4) = min(q1(:));
        con_out.c1(cnt,5) = max(gammaN(:));
        con_out.c1(cnt,6) = min(gammaN(:));
        disp(['max_t: ' num2str(con_out.c1(cnt,1)) '  min_t: ' num2str(con_out.c1(cnt,2))]);
        disp(['max_q1: ' num2str( con_out.c1(cnt,3)) '  min_q1: ' num2str( con_out.c1(cnt,4))]);
        disp(['max_ga1: ' num2str( con_out.c1(cnt,5)) '  min_ga1: ' num2str( con_out.c1(cnt,6))]);
        
        
    elseif mod(cnt,C) == 2
        disp('Pro on C2');
        
        tmp = gammaN.*q2;
        tmp(isnan(tmp)) = 0;
        gammaN = tmp.*((p./(sum(tmp,2)))*I_n');
        q2 = (tmp./gammaN);
        gamma2 = gammaN;
        
        con_out.c2(cnt,1) = max(tmp(:));
        con_out.c2(cnt,2) = min(tmp(:));
        con_out.c2(cnt,3) = max(q2(:));
        con_out.c2(cnt,4) = min(q2(:));
        con_out.c2(cnt,5) = max(gammaN(:));
        con_out.c2(cnt,6) = min(gammaN(:));
        disp(['max_t: ' num2str(con_out.c2(cnt,1)) '  min_t: ' num2str(con_out.c2(cnt,2))]);
        disp(['max_q2: ' num2str( con_out.c2(cnt,3)) '  min_q2: ' num2str( con_out.c2(cnt,4))]);
        disp(['max_ga2: ' num2str( con_out.c2(cnt,5)) '  min_ga2: ' num2str( con_out.c2(cnt,6))]);
        
        
    else
        disp('Pro on C3');
        
        tmp = gammaN.*q3;
        tmp(isnan(tmp)) = 0;
        gammaN = tmp.*(I_m*(q'./(sum(tmp,1))));
        q3 = (tmp./gammaN);
        gamma3 = gammaN;
        
        con_out.c3(cnt,1) = max(tmp(:));
        con_out.c3(cnt,2) = min(tmp(:));
        con_out.c3(cnt,3) = max(q3(:));
        con_out.c3(cnt,4) = min(q3(:));
        con_out.c3(cnt,5) = max(gammaN(:));
        con_out.c3(cnt,6) = min(gammaN(:));
        disp(['max_t: ' num2str(con_out.c3(cnt,1)) '  min_t: ' num2str(con_out.c3(cnt,2))]);
        disp(['max_q3: ' num2str( con_out.c3(cnt,3)) '  min_q3: ' num2str( con_out.c3(cnt,4))]);
        disp(['max_ga3: ' num2str( con_out.c3(cnt,5)) '  min_ga3: ' num2str( con_out.c3(cnt,6))]);
        
    end
    
     
    if cnt > 6 
        err = (sum(sum(abs(gammaN-gamma1)))+sum(sum(abs(gammaN-gamma2)))+sum(sum(abs(gammaN-gamma3))));
       % err = max(max(abs(gamma1 - gammaN) + abs(gamma2 - gammaN) + abs(gamma3 - gammaN)));
        
        err_hold(cnt) = err;
        disp(['Error at iteration ' num2str(cnt) ' is: ' num2str(err)]);
 
    end
    
%         if mod(cnt,20) == 1
%             disp(['Error at iteration ' num2str(cnt) ' is: ' num2str(error)]);
%         end
    
    cnt = cnt+1;
end

iter = cnt - 1;
Map = gammaN;

%plot gamma
% pcolor(x,y,gammaN);
% shading flat;
% colormap gray
% colormap(flipud(colormap));
% colorbar;


end


%% test for capasity constraint OT
N = 100;
x = 0:1/(N-1):1;
y = 0:1/(N-1):1;

p = 1*ones(N,1);
q = 1*ones(N,1);

dis = abs(bsxfun(@minus,x,y')).^2;
dis = dis.^(1);
dis = dis/max(dis(:));
%dis = exp(-(0.5*dis)*1000);
figure,imagesc(dis);
%figure,plot3(repmat(x,N,1),repmat(y',1,N),dis,'r.');
figure,mesh(dis);
%% tset among test_equal.m test_sinkhorn.m test_partial.m with equal constraint
% da = 0.01:0.01:1;
% db = 0.01:0.01:1;
% mu_a = 0.3;delta_a=0.01;
% mu_b = [0.1,0.3,0.7,0.9];
% delta_b = [0.01,0.01,0.05,0.08];
% p = exp(-(da'-mu_a).^2/delta_a);p = p/sum(p);% m*1 
% b = zeros(length(db),length(mu_b));% n*k 
% for i = 1:length(b(1,:))
%     b(:,i) = exp(-(db'-mu_b(i)).^2/delta_b(i));
%     b(:,i) = b(:,i)/sum(sum(b(:,i)));
% end
% q = b(:,3);
% figure,plot(1:length(da),p,'r.');
% figure,plot(1:length(db),q,'b.');
% dis = abs(bsxfun(@minus,da',db)).^(2);%
% dis = dis/max(dis(:));
% figure,imagesc(dis);



lambda = 1/100;
stop_tol = 1.0e1/(length(p)*length(q));
stop_tol = 1.0e-3;
max_iter_cons = 5000;
constraint = 1*ones(length(p),length(q));

%%
[Map_cons,iter_cons,err_cons,con_out] = Constrained_OT(p,q,dis,constraint,lambda,stop_tol,max_iter_cons);

%%
% figure,plot3(repmat(da',1,length(db)),repmat(db,length(da),1),Map_cons,'b.');
figure,imagesc(Map_cons);
%figure,plot3(repmat(x,N,1),repmat(y',1,N),Map_cons,'r.');
figure,mesh(Map_cons);

figure,plot(1:iter_cons,err_cons(1:iter_cons),'r.');
figure,plot(1:length(q),sum(Map_cons,1),'b.');
figure,plot(1:length(p),sum(Map_cons,2),'b.');
%%
figure,title('display C1')
for i = 1:6
    subplot(2,3,i),plot(1:3:iter_cons,con_out.c1(1:3:iter_cons,i),'r.');
end
figure,title('display C2')
for i = 1:6
    subplot(2,3,i),plot(2:3:iter_cons,con_out.c2(2:3:iter_cons,i),'b.');
end
figure,title('display C3')
for i = 1:6
    subplot(2,3,i),plot(3:3:iter_cons,con_out.c3(3:3:iter_cons,i),'g.');
end




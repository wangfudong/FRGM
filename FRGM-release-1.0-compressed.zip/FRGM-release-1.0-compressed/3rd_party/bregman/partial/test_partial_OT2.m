%test partial
%%
sig = 0.1;
m = 10;
n = 10;
r1 = 1;
r2 = 2;
theta1 = 0:1/m*pi:2*pi;
theta2 = theta1(randperm(length(theta1)));
theta2 = 0:1/n*pi:2*pi;

X1 = [cos(theta1);sin(theta1)]'*r1;
X2 = [cos(theta2);sin(theta2)]'*r2;
X1 = X1+randn(size(X1))*sig;
X2 = X2+randn(size(X2))*sig;

D12 = (bsxfun(@minus,X1(:,1),X2(:,1)').^2 + bsxfun(@minus,X1(:,2),X2(:,2)').^2).^(0.5);
D12 = D12/max(D12(:));
Map0 = asgHun(-D12);

figure,plot(X1(:,1),X1(:,2),'r.',X2(:,1),X2(:,2),'b+');
figure,imagesc([D12;Map0]);

%%

lambda = 1/100;
mass_rate = 1;
tol = 1.0e-4;
act_thresh = 1.0e-3;
max_iter = 5000;

p = ones(length(X1(:,1)),1);
q = ones(length(X2(:,1)),1);

tic;
[Map_part,iter_part,err,part_out] = partial_OT(p,q,D12,lambda,mass_rate,tol,max_iter);
time = toc;
%%
figure,title('partial Map_part'),imagesc([Map_part;asgHun(Map_part);Map0]);
X12 = Map0*X2;
X12_part = Map_part*X2;
figure,plot(X1(:,1),X1(:,2),'r.',X2(:,1),X2(:,2),'b+',X12_part(:,1),X12_part(:,2),'b*');hold on;
line([X1(:,1),X12(:,1)]',[X1(:,2),X12(:,2)]','color','g');hold on;
line([X1(:,1),X12_part(:,1)]',[X1(:,2),X12_part(:,2)]','color','m')


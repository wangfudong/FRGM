function [Map,iter,err_hold,part_out]=partial_OT(p,q,M,lambda,mass_rate,tol,max_iter)
% input
% p: histogram m*1 vector, marginal constraint
% q: histogram n*1 vector, marginal constraint
% M: M_i,j=d(p_i,q_j), ground-distance matrix
% lambda: positive,parameter for entropy regularization,
% mass_rate: fraction of the min{sum(p),sum(q)} to transport, [0,1]
% tolerance: tolerance for the relative error to stop iteration
% act_thresh: threshold to detect the active region
% max_iter: maxima of the iteration

%output
% Map: transportation map, m*n matrix
% active: active region
% inactive: inactive region
% entropy: entropy of M
% iter: iteration times
% error_hold: errors in iteration


%% checking the input
if nargin < 4
    error('no enough inputs');
end

if nargin < 5 || isempty(mass_rate)
    mass_rate = 1;
end

if nargin < 6 || isempty(tol)
    tol = 1.0e-5;
end

if nargin < 7 || isempty(max_iter)
    max_iter = 5000;
end

% M = M/median(M(:));
% M = M/max(M(:));
% if max(max(M*lambda))>=300
%     disp('lambda should be smaller !!');
% end

%% preparation to the iteration
verbose = 0;

gamma0 = exp(-1/lambda * M);


I_p = (p>0);
%I_p_index = find(p > 0);
I_q = (q>0);
%I_q_index = find(q > 0);
p = p(I_p);
q = q(I_q);
gamma0 = gamma0(I_p,I_q);
m = length(p);
%dm = 1/m;
I_m = ones(m,1);
n = length(q);
%dn = 1/n;
I_n = ones(n,1);

dis_old = 1;
mass = mass_rate * min(sum(p),sum(q));
err_hold = zeros(max_iter,1);
err = 1;
cnt = 1;
C = 3;

q1 = ones(m,n);
q2 = q1;
q3 = q1;
part_out.c1 = zeros(max_iter,6);
part_out.c2 = zeros(max_iter,6);
part_out.c3 = zeros(max_iter,6);

gamma1 = gamma0;
gamma2 = gamma0;
gamma3 = gamma0;
gammaN = gamma0;

clear gamma0

%% iteration loop.
% noticing the numerical accuracy resulted by tiny as denominator/minuend
% or huge values as numerator/subtrahend

while err > tol && cnt <= max_iter
    
    if mod(cnt,C) == 1
        
        tmp = gammaN.*q1;
        tmp(isnan(tmp)) = 0;
        gammaN = (tmp * mass)/(sum(sum(tmp)));
        q1 = tmp./gammaN;
        gamma1 = gammaN;
        
        if verbose >0 && mod(cnt,50) == 1
            disp('Pro on C1');
            part_out.c1(cnt,1) = max(tmp(:));
            part_out.c1(cnt,2) = min(tmp(:));
            part_out.c1(cnt,3) = max(q1(:));
            part_out.c1(cnt,4) = min(q1(:));
            part_out.c1(cnt,5) = max(gammaN(:));
            part_out.c1(cnt,6) = min(gammaN(:));
            disp(['  max_t: ' num2str(part_out.c1(cnt,1)) '  min_t: ' num2str(part_out.c1(cnt,2))]);
            disp(['  max_q1: ' num2str( part_out.c1(cnt,3)) '  min_q1: ' num2str( part_out.c1(cnt,4))]);
            disp(['  max_ga1: ' num2str( part_out.c1(cnt,5)) '  min_ga1: ' num2str( part_out.c1(cnt,6))]);
        end
        
    elseif mod(cnt,C) == 2
        
        tmp = gammaN.*q2;
        tmp(isnan(tmp)) = 0;
        gammaN = tmp;
        index = find(sum(tmp,2) > p);
        gammaN(index,:) = tmp(index,:).*(p(index)./sum(tmp(index,:),2)*I_n');
        % gammaN = tmp.*(min(p./(sum(tmp,2)),1)*I_n');
        q2 = tmp./gammaN;
        gamma2 = gammaN;
        
        if verbose >0 && mod(cnt,50) == 1
            disp('Pro on C2');
            part_out.c2(cnt,1) = max(tmp(:));
            part_out.c2(cnt,2) = min(tmp(:));
            part_out.c2(cnt,3) = max(q2(:));
            part_out.c2(cnt,4) = min(q2(:));
            part_out.c2(cnt,5) = max(gammaN(:));
            part_out.c2(cnt,6) = min(gammaN(:));
            disp(['  max_t: ' num2str(part_out.c2(cnt,1)) '  min_t: ' num2str(part_out.c2(cnt,2))]);
            disp(['  max_q2: ' num2str( part_out.c2(cnt,3)) '  min_q2: ' num2str( part_out.c2(cnt,4))]);
            disp(['  max_ga2: ' num2str( part_out.c2(cnt,5)) '  min_ga2: ' num2str( part_out.c2(cnt,6))]);
        end
        
    else
        
        tmp = gammaN.*q3;
        tmp(isnan(tmp)) = 0;
        gammaN = tmp;
        index = find(sum(tmp,1) > q');
        gammaN(:,index) = tmp(:,index).*(I_m*(q(index)'./sum(tmp(:,index),1)));
        %gammaN = tmp.*(I_m*min(q'./(sum(tmp,1)),1));
        q3 = tmp./gammaN;
        gamma3 = gammaN;
        
        if verbose > 0 && mod(cnt,50) == 1
            disp('Pro on C3');
            part_out.c3(cnt,1) = max(tmp(:));
            part_out.c3(cnt,2) = min(tmp(:));
            part_out.c3(cnt,3) = max(q3(:));
            part_out.c3(cnt,4) = min(q3(:));
            part_out.c3(cnt,5) = max(gammaN(:));
            part_out.c3(cnt,6) = min(gammaN(:));
            disp(['  max_t: ' num2str(part_out.c3(cnt,1)) '  min_t: ' num2str(part_out.c3(cnt,2))]);
            disp(['  max_q3: ' num2str( part_out.c3(cnt,3)) '  min_q3: ' num2str( part_out.c3(cnt,4))]);
            disp(['  max_ga3: ' num2str( part_out.c3(cnt,5)) '  min_ga3: ' num2str( part_out.c3(cnt,6))]);
        end
        
    end
    
    if cnt > 6% && mod(cnt,C) == 2 % 2 ,1 is better than 3
         err = mean(sum(sum(abs(gamma1-gammaN))) + sum(sum(abs(gamma2-gammaN))) + sum(sum(abs(gamma3-gammaN))));
      %  err = max(max(abs(gamma1 - gammaN) + abs(gamma2 - gammaN) + abs(gamma3 - gammaN)));
      %  dis = 1/3*(sum(sum(gamma1.*M + gamma2.*M + gamma3.*M)));
%         dis = 1/3*sum(sum(gamma1.*M + gamma1.*(gamma1>=1.0e-200).*log(max(gamma1,1.0e-200)) + ...
%         gamma2.*M + gamma2.*(gamma2>=1.0e-200).*log(max(gamma2,1.0e-200)) +...
%         gamma3.*M + gamma3.*(gamma3>=1.0e-200).*log(max(gamma3,1.0e-200))));
       % dis = sum(sum(gamma1.*M));
       % err = abs(dis/dis_old - 1);
       %err = max(abs(gamma1*))
       % dis_old = dis;
       % err_hold(cnt) = err;
    end
    
%     if mod(cnt,50) == 1
%         disp(['        Err at partial_iter ' num2str(cnt) ' is: ' num2str(err)]);
%     end
    
    cnt = cnt + 1;
    
end

iter = cnt - 1;

 disp(['      Err at last_partial_iter: ' num2str(iter)  ' is: ' num2str(err)]);
 
Map = gammaN;
clear gammaN


% entropy = -sum(sum(Map.*log(Map)));
%
% act.source = find(sum(Map,2) > (mass*act_thresh));
% act.target = find(sum(Map,1)' > (mass*act_thresh));
% inact.source = find(sum(Map,2) <= (mass*act_thresh));
% inact.target = find(sum(Map,1)' <= (mass*act_thresh));
%
% act.source = find(sum(Map,2)./p > 0.1);
% act.target = find(sum(Map,1)'./q > 0.1);
% inact.source = find(sum(Map,2)./p <= 0.1);
% inact.target = find(sum(Map,1)'./q <= 0.1);

% entropy = nan;
% act = nan;
% inact = nan;


end









%%
x1 = load('x1.mat');x1 = x1.x1;
x2 = load('x2.mat');x2 = x2.x2;
y1 = load('y1.mat');y1 = y1.y1;
y2 = load('y2.mat');y2 = y2.y2;

p = ones(length(x1),1);
q = ones(length(y1),1);
dis = abs(bsxfun(@minus,x1,y1')).^2 + abs(bsxfun(@minus,x2,y2')).^2;
dis = dis.^(1);
dis = dis/max(dis(:));
%figure,plot3(repmat((1:1:length(p)),length(q),1),repmat((1:1:length(q))',1,length(p)),dis,'r.');
figure,mesh(dis);
figure,title('ground distance');
imagesc(dis);
axis equal

%% tset among test_equal.m test_sinkhorn.m test_partial.m with equal constraint
da = 0.01:0.01:1;
db = 0.01:0.01:1;
mu_a = 0.3;delta_a=0.01;
mu_b = [0.1,0.3,0.7,0.9];
delta_b = [0.01,0.01,0.05,0.08];
p = exp(-(da'-mu_a).^2/delta_a);p = p/sum(p);% m*1 
b = zeros(length(db),length(mu_b));% n*k 
for i = 1:length(b(1,:))
    b(:,i) = exp(-(db'-mu_b(i)).^2/delta_b(i));
    b(:,i) = b(:,i)/sum(sum(b(:,i)));
end
q = b(:,3);
figure,plot(1:length(da),p,'r.');
figure,plot(1:length(db),q,'b.');
dis = abs(bsxfun(@minus,da',db)).^(2);%a
dis = dis/max(dis(:));
figure,imagesc(dis);

%%
lambda = 1/100;
mass_rate = 0.7;
tol = 1.0e-4;
act_thresh = 1.0e-3;
max_iter = 5000;

tic;
[Map_part,iter_part,err,part_out] = partial_OT(p,q,dis,lambda,mass_rate,tol,max_iter);
time = toc;

figure,title('partial Map_part'),imagesc(Map_part);
%figure,plot3(repmat((1:1:length(p)),length(q),1),repmat((1:1:length(q))',1,length(p)),Map_part,'r.');
figure,mesh(Map_part);

%%
figure,plot(x1,x2,'k.',y1,y2,'k.');hold on,
plot(x1(act.source),x2(act.source),'r.',y1(act.target),y2(act.target),'g.');

figure,plot(1:iter_part,err(1:iter_part),'r.');


figure,plot(1:length(q),sum(Map_part,1),'b.');
figure,plot(1:length(p),sum(Map_part,2),'b.');
%%
figure,title('display C1')
for i = 1:6
    subplot(2,3,i),plot(1:3:iter_part,part_out.c1(1:3:iter_part,i),'r.');
end
figure,title('display C2')
for i = 1:6
    subplot(2,3,i),plot(2:3:iter_part,part_out.c2(2:3:iter_part,i),'b.');
end
figure,title('display C3')
for i = 1:6
    subplot(2,3,i),plot(3:3:iter_part,part_out.c3(3:3:iter_part,i),'g.');
end




















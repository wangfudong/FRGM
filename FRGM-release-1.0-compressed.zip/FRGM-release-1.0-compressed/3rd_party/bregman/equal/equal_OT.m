function [Map,iter,err_hold,equ_out]=equal_OT(p,q,dis,lambda,stop_tol,max_iter,verbose)
% input
% p: histogram m*1 vector, marginal constraint
% q: histogram n*1 vector, marginal constraint
% M: M_i,j=d(p_i,q_j), ground-distance matrix
% lambda: positive,parameter for entropy regularization,
% tolerance: tolerance for the relative error to stop iteration
% max_iter: maxima of the iteration

%output
% Map: transportation map, m*n matrix
% iter: iteration times
% error_hold: errors in iteration

%% checking the input
if nargin < 4
    error('no enough inputs');
end

if nargin < 5 || isempty(stop_tol)
    stop_tol = 1.0e-5;
end

if nargin < 6 || isempty(max_iter)
    max_iter = 5000;
end

if nargin < 7 || isempty(verbose)
    verbose = 1;
end

% M = M/median(M(:));
% dis = dis/max(dis(:));
% if max(max(M*lambda))>=300
%     disp('lambda should be smaller !!');
% end

%% preparation to the iteration

gamma0 = exp(-1/lambda * dis);
I_p = (p>0);
%I_p_index = find(p > 0);
I_q = (q>0);
%I_q_index = find(q > 0);
p = p(I_p);
q = q(I_q);
gamma0 = gamma0(I_p,I_q);
m = length(p);
%dm = 1/m;
I_m = ones(m,1);
n = length(q);
%dn = 1/n;
I_n = ones(n,1);

err_hold = zeros(max_iter,1);
err = 1;
cnt = 1;
C = 2;
dis1 = 1;
dis2 = 1;

equ_out.c1 = zeros(max_iter,3);
equ_out.c2 = zeros(max_iter,3);

gamma1 = gamma0;
gamma2 = gamma0;
gammaN = gamma0;

clear gamma0

%% iteration loop.
% noticing the numerical accuracy resulted by tiny as denominator/minuend
% or huge values as numerator/subtrahend

while err > stop_tol && cnt <= max_iter
    
    if mod(cnt,C) == 1
        %   disp('Pro on C1');
        
        gammaN(isnan(gammaN)) = 0;
        gammaN = gammaN.*(p./sum(gammaN,2)*I_n');
        gamma1 = gammaN;
        dis1 = sum(sum(gamma1.*dis));
        
        equ_out.c1(cnt,1) = max(gammaN(:));
        equ_out.c1(cnt,2) = min(gammaN(:));
        equ_out.c1(cnt,3) = dis1;
        if verbose > 0
            disp(['    max_C1: ' num2str(equ_out.c1(cnt,1)) '  min_C1: ' num2str(equ_out.c1(cnt,2))]);
        end
        
    else
        %   disp('Pro on C2');
        
        gammaN(isnan(gammaN)) = 0;
        gammaN = gammaN.*(I_m*(q'./sum(gammaN,1)));
        gamma2 = gammaN;
        dis2 = sum(sum(gamma2.*dis));
        
        equ_out.c2(cnt,1) = max(gammaN(:));
        equ_out.c2(cnt,2) = min(gammaN(:));
        equ_out.c2(cnt,3) = dis2;
        if verbose > 0
            disp(['    max_C2: ' num2str(equ_out.c2(cnt,1)) '  min_C2: ' num2str(equ_out.c2(cnt,2))]);
        end
        
    end
    
    if cnt >= 2
        err = (abs(dis1/dis2 - 1));
        %   err = 0.5*(abs(dis1/dis2 - 1) + abs(dis2/dis1 - 1));
        %  err = sum(sum(abs(gamma1 - gammaN) + abs(gamma2 - gammaN)));
        %   err = max(max(abs(gamma1 - gammaN) + abs(gamma2 - gammaN)));
        err_hold(cnt) = err;
        if verbose > 0
            disp(['    error at iteration ' num2str(cnt) ' is: ' num2str(err)]);
        end
    end
    
    %     if mod(cnt,20) == 1 && verbose > 0
    %         disp(['Error at iteration ' num2str(cnt) ' is: ' num2str(err)]);
    %     end
    
    cnt = cnt + 1;
    
end

iter = cnt - 1;
%disp(['Error at last iteration ' num2str(iter) ' is: ' num2str(err)]);

Map = gammaN;

end










